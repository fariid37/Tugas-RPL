#include<iostream>
using namespace std;
int main()
double pi() {
    return 3.14;
}

int main () {
    cout << "nilai pi: " << pi();
    return 0;
}