#include <iostream>
using namespace std;

void ulang(string nama, int n=1) {
    int i;
    for (i=1; i<=n; i++) {
        cout << nama;
    }
}


int main() {
    ulang("UwU ", 30);
    return 0;

}