#include<iostream>
using namespace std;

void hello() {
    cout << "hello, world!" << endl;
}

int main() {
    hello();
    return 0;
}