#include<iostream>
using namespace std;

int main()
{
    string i;
    cin >> i;
    cout << i;
    return 0;
}